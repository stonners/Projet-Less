
fetch('https://pokeapi.co/api/v2/pokemon?limit=1049&offset=1', {
    method: 'GET'

}).then(response => response.json())
    .then(json => listPokemon(json)
    ).catch(function (err) {
    console.log("il y a eu un problème avec l'opération fetch : " + err.message);
});

function listPokemon(tab){
let listPoke = $("#listPoke");

    for (let i = 0; i < tab.results.length; i++) {

        let trPoke = $("<tr></tr>");
        let tdPoke = $("<td></td>").html(tab.results[i].name);
        $(tdPoke).attr("id",tab.results[i].name);


        $(trPoke).append(tdPoke);
        $(listPoke).append(trPoke);

    }

}