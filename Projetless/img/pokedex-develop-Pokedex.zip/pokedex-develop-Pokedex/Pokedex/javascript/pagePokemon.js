$("td").on('click',pok);

function pok() {
    console.log("test");
    let API = 'https://pokeapi.co/api/v2/pokemon/'
    fetch(API, {
        method: "GET",
    })
        .then(response => response.json())
        .then(json => createPage(json))
        .catch(err => console.log(err));
}
function createPage(pok){
    let type=" ";
    let div = $("#pokemon");
    div.append($("<img src="+pok.sprites.back_default+">"));
    div.append($("<h2></h2>").html(pok.name));
    for(let i=0;i<pok.types.length;i++){
        type= type.concat(" ",pok.types[i].type.name);

    }
    div.append($("<article></article>").html(type));
    let ability=pok.abilities[0].ability.name;
    for(let i=1;i<pok.abilities.length;i++){
        ability= ability.concat("/",pok.abilities[i].ability.name);
    }
    div.append($("<article></article>").html(ability));
    div.append($("<article></article>").html("height:"+pok.height+"m"));
    div.append($("<article></article>").html("Weight:"+pok.weight+"kg"));
    let stat=$("<article></article>").html("Base stats");
    stat.append($("<p></p>").html("HP"+pok.stats[0].base_stat));
    stat.append($("<p></p>").html("Atk"+pok.stats[1].base_stat));
    stat.append($("<p></p>").html("Def"+pok.stats[2].base_stat));
    stat.append($("<p></p>").html("Sp Atk"+pok.stats[3].base_stat));
    stat.append($("<p></p>").html("Sp def"+pok.stats[4].base_stat));
    stat.append($("<p></p>").html("Speed"+pok.stats[5].base_stat));
    div.append(stat);
    let cap=$("<article></article>").html("Move List");
    for(let i=0;i<pok.moves.length;i++){
        cap.append($("<p></p>").html(pok.moves[i].move.name))
    }
    div.append(cap);
}